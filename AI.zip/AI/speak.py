from datetime import date

today = date.today()
d2 = today.strftime("%B, %d, %Y")
print("d2 =", d2)