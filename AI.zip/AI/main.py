import speech_recognition
import pyttsx3
from datetime import date, datetime

robot_ear = speech_recognition.Recognizer()
robot_mouse = pyttsx3.init()
robot_brain = ""
while True:
    with speech_recognition.Microphone() as mic:
        print("Robot: Listening")
        audio =robot_ear.record(mic, duration=3)
        
    print("Robot: ... ") 
        
    try:    
        you = robot_ear.recognize_google(audio)
    except:
        you = ""
    print("You: " + you)

    if you == "":
        robot_brain = "Try again"
    elif "hello" in you:
        robot_brain = "Hello Huy"
    elif "today" in you:
        today = date.today()
        robot_brain = today.strftime("%B, %d, %Y")
    elif "time" in you:
        now = datetime.now()
        robot_brain = now.strftime("%H hours, %M minutes")
    elif "bye" in you:
        robot_brain = "Bye"
        print("Robot: " + robot_brain)
        robot_mouse.say(robot_brain)
        robot_mouse.runAndWait()
        break
    else:
        robot_brain = "thank you"
    
   
        
    print("Robot: " + robot_brain)
    robot_mouse.say(robot_brain)
    robot_mouse.runAndWait()
        
