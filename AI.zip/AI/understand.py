
you = "hello"

if you == "":
    robot_brain = "Try again"
elif you == "hello":
    robot_brain = "Hello Huy"
else:
    robot_brain = "thank you"
    
print(robot_brain)